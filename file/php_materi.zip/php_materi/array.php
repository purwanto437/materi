<?php
$mahasiswa = [
    "nama" => "Budi",
    "umur" => 21,
    "jurusan" => "Informatika"
];

echo $mahasiswa["nama"];
?>