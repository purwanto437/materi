Tipe Data	Contoh
String	<?php $nama = "Budi"; ?>
Integer	<?php $umur = 20; ?>
Float	<?php $tinggi = 165.5; ?>
Boolean	<?php $isLulus = true; ?>
Array	<?php $buah = ["apel", "jeruk"]; ?>