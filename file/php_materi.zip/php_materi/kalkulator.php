<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kalkulator Sederhana</title>
</head>
<body>

<h2>Kalkulator Sederhana dengan PHP</h2>

<form method="post">
    <input type="number" name="angka1" placeholder="Angka pertama" required>
    <select name="operator">
        <option value="+">+</option>
        <option value="-">-</option>
        <option value="*">×</option>
        <option value="/">÷</option>
    </select>
    <input type="number" name="angka2" placeholder="Angka kedua" required>
    <button type="submit" name="hitung">Hitung</button>
</form>

<?php
if (isset($_POST['hitung'])) {
    $angka1 = $_POST['angka1'];
    $angka2 = $_POST['angka2'];
    $operator = $_POST['operator'];
    $hasil = 0;

    if ($operator == '+') {
        $hasil = $angka1 + $angka2;
    } elseif ($operator == '-') {
        $hasil = $angka1 - $angka2;
    } elseif ($operator == '*') {
        $hasil = $angka1 * $angka2;
    } elseif ($operator == '/') {
        if ($angka2 == 0) {
            echo "<p style='color:red;'>Tidak bisa dibagi dengan nol!</p>";
            exit;
        } else {
            $hasil = $angka1 / $angka2;
        }
    }

    echo "<h3>Hasil: $hasil</h3>";
}
?>

</body>
</html>
