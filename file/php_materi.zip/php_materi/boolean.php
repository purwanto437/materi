<?php
$nilai = 85;
$lulus = $nilai >= 75;

if ($lulus) {
    echo "Selamat, kamu lulus!";
} else {
    echo "Maaf, kamu belum lulus.";
}
?>