<?php
$nama = "Andi";
$umur = 20;
echo "Nama saya $nama dan umur saya $umur tahun";
?>