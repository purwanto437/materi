<?php
$harga = 12000.00; 

$jumlah = 3;
$total = $harga * $jumlah;

echo "Total harga: Rp " . $total;
?>