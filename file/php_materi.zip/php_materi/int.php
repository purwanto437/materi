<?php 
	$x = 20;
	$y = 10;

	echo $x + $y; //penjumlahan
    echo "<br>";
    echo $x - $y; //pengurangan
    echo "<br>";
    echo $x * $y; //perkalian
    echo "<br>"; 
    echo $x / $y; //pembagian
?>