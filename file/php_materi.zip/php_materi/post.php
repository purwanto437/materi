<form method="post">
    Nama: <input type="text" name="nama"><br>
    <input type="submit" value="Kirim">
</form>

<?php
if (isset($_POST['nama'])) {
    echo "Halo, " . $_POST['nama'];
}
?>